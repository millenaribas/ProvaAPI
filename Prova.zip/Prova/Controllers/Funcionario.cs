using Prova.Data;
using Prova.Models;
using Microsoft.AspNetCore.Mvc;

namespace Prova;
[Route("api/[controller]")]
public class FuncionarioController : ControllerBase
{
    private readonly AppDbContext _context;

    public FuncionarioController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost("cadastrar")]
    public IActionResult CadastrarFuncionario([FromBody] Funcionario funcionario)
    {
        if (funcionario == null)
            return BadRequest();

        _context.Funcionarios.Add(funcionario);
        _context.SaveChanges();

        return Ok();
    }

    [HttpGet("listar")]
    public IActionResult ListarFuncionarios()
    {
        var funcionarios = _context.Funcionarios.ToList();
        return Ok(funcionarios);
    }
}