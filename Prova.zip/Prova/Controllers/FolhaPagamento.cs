using Prova.Data;
using Prova.Models;
using Microsoft.AspNetCore.Mvc;

namespace Prova;
[Route("api/[controller]")]
public class FolhaController : ControllerBase
{
    private readonly AppDbContext _context;

    public FolhaController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost("cadastrar")]
    public IActionResult CadastrarFolhaPagamento([FromBody] FolhaPagamento folhaPagamento)
    {
        if (folhaPagamento == null)
            return BadRequest();

        // Encontrar o funcionário correspondente
        var funcionario = _context.Funcionarios.FirstOrDefault(f => f.Id == folhaPagamento.FuncionarioId);

        if (funcionario == null)
            return NotFound("Funcionário não encontrado");

        // Calcular as informações da folha de pagamento
        folhaPagamento.SalarioBruto = funcionario.ValorHora * folhaPagamento.HorasTrabalhadas;
        // Implemente os cálculos para IR, INSS, FGTS e Salário Líquido aqui.

        _context.FolhasPagamento.Add(folhaPagamento);
        _context.SaveChanges();

        return Ok();
    }

    [HttpGet("listar")]
    public IActionResult ListarFolhasPagamento()
    {
        var folhasPagamento = _context.FolhasPagamento.ToList();
        return Ok(folhasPagamento);
    }

    [HttpGet("buscar/{cpf}/{mes}/{ano}")]
    public IActionResult BuscarFolhaPagamento(string cpf, int mes, int ano)
    {
        // Implemente a busca de folha de pagamento por CPF, mês e ano aqui.
        var folhaPagamento = _context.FolhasPagamento.FirstOrDefault(f => f.Funcionario.CPF == cpf && f.MesAno.Month == mes && f.MesAno.Year == ano);

        if (folhaPagamento == null)
            return NotFound();

        return Ok(folhaPagamento);
    }
}