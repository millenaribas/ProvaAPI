﻿namespace Prova.Models;
public class FolhaPagamento
{
    public int Id { get; set; }
    public int FuncionarioId { get; set; }
    public Funcionario? Funcionario { get; set; }
    public int Mes { get; set; }
    public int Ano { get; set; }
    public decimal HorasTrabalhadas { get; set; }
    public decimal SalarioBruto { get; internal set; }
    public object MesAno { get; set; }
}
