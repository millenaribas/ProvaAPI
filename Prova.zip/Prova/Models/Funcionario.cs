﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.Net.Http.Headers;

namespace Prova.Models;
public class Funcionario
{
    public int Id { get; set; }
    public string? Nome { get; set; }
    public string? CPF { get; set; }
    public decimal SalarioHora { get; set; }
    public decimal ValorHora { get; set;}
}

